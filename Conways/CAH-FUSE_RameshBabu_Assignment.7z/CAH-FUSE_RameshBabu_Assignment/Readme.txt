Prerequistes:
- should have eclipse to run the code, you can download from the below link
http://www.eclipse.org/downloads/packages/eclipse-ide-java-developers/keplersr1

- JDK and JRE should be installed, you can download from below link
  http://www.oracle.com/technetwork/java/javase/downloads/jdk8-downloads-2133151.html

- we can create a jar file if user dont want to see the code

Steps to  build:
- copy the zip folder to a specific location and unzip it
- import the folder to Eclipse
- Right clik on the Livedead.java file and run as Java applicaiton

Test:

Program will guide you through to input values and test
** Please enter only 1's and 0's as we havent bar any wild characters**